package com.mko.xperiaotaprobe;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.method.ScrollingMovementMethod;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final String READ_PERMISSION =
            "com.sonyericsson.updatecenter.permission.READ_FIRMWARE_UPDATES";
    private static final String AUTHORITY = "com.sonyericsson.updatecenter.provider";
    private static final Uri FIRMWARE_URI =
            Uri.parse("content://" + AUTHORITY + "/firmwareUpdate");
    private static final int MAX_REPORT_CHARS = 250_000;

    private TextView reportView;
    private String lastReport = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(createContentView());
        readFirmwareTable();
    }

    private View createContentView() {
        int padding = dp(18);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(padding, padding, padding, padding);
        content.setBackgroundColor(Color.rgb(250, 250, 250));

        TextView title = new TextView(this);
        title.setText("Xperia OTA Probe");
        title.setTextSize(25);
        title.setTextColor(Color.BLACK);
        title.setGravity(Gravity.START);
        title.setPadding(0, 0, 0, dp(8));
        content.addView(title, matchWrap());

        TextView description = new TextView(this);
        description.setText(
                "أداة تشخيص قراءة فقط. لا تحتوي إنترنت أو تخزين، ولا تغيّر Update Center أو النظام.\n" +
                "افتح تحديث النظام، افحص مرة واحدة، ثم ارجع واضغط قراءة نتيجة Sony.");
        description.setTextSize(15);
        description.setTextColor(Color.DKGRAY);
        description.setLineSpacing(0, 1.15f);
        description.setPadding(0, 0, 0, dp(14));
        content.addView(description, matchWrap());

        Button openUpdate = makeButton("1) افتح تحديث النظام");
        openUpdate.setOnClickListener(v -> openSystemUpdate());
        content.addView(openUpdate, matchWrapWithBottom(dp(8)));

        Button refresh = makeButton("2) اقرأ نتيجة Sony");
        refresh.setOnClickListener(v -> readFirmwareTable());
        content.addView(refresh, matchWrapWithBottom(dp(8)));

        Button copy = makeButton("نسخ التقرير");
        copy.setOnClickListener(v -> copyReport());
        content.addView(copy, matchWrapWithBottom(dp(14)));

        reportView = new TextView(this);
        reportView.setTextSize(12);
        reportView.setTextColor(Color.rgb(20, 20, 20));
        reportView.setBackgroundColor(Color.WHITE);
        reportView.setPadding(dp(12), dp(12), dp(12), dp(12));
        reportView.setTextIsSelectable(true);
        reportView.setTypeface(android.graphics.Typeface.MONOSPACE);
        reportView.setMovementMethod(new ScrollingMovementMethod());
        content.addView(reportView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(content);
        return scroll;
    }

    private Button makeButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextSize(15);
        return button;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams matchWrapWithBottom(int bottomMargin) {
        LinearLayout.LayoutParams params = matchWrap();
        params.bottomMargin = bottomMargin;
        return params;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void openSystemUpdate() {
        Intent intent = new Intent(Settings.ACTION_SYSTEM_UPDATE_SETTINGS);
        try {
            startActivity(intent);
        } catch (Exception firstFailure) {
            try {
                startActivity(new Intent(Settings.ACTION_DEVICE_INFO_SETTINGS));
            } catch (Exception secondFailure) {
                Toast.makeText(this, "تعذر فتح صفحة تحديث النظام", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void readFirmwareTable() {
        StringBuilder report = new StringBuilder(4096);
        report.append("XPERIA OTA PROBE v1.0\n");
        report.append("Time: ")
                .append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss Z", Locale.US)
                        .format(new Date()))
                .append('\n');
        report.append("Model: ").append(Build.MODEL).append('\n');
        report.append("Device: ").append(Build.DEVICE).append('\n');
        report.append("Build display: ").append(Build.DISPLAY).append('\n');
        report.append("Android: ").append(Build.VERSION.RELEASE)
                .append(" (SDK ").append(Build.VERSION.SDK_INT).append(")\n");
        report.append("Security patch: ").append(Build.VERSION.SECURITY_PATCH).append('\n');
        report.append("URI: ").append(FIRMWARE_URI).append("\n\n");

        int permissionState = checkSelfPermission(READ_PERMISSION);
        report.append("Permission: ")
                .append(permissionState == PackageManager.PERMISSION_GRANTED ? "GRANTED" : "DENIED")
                .append('\n');

        ProviderInfo provider = getPackageManager().resolveContentProvider(AUTHORITY, 0);
        report.append("Provider: ")
                .append(provider == null ? "NOT_VISIBLE" : provider.packageName + "/" + provider.name)
                .append("\n\n");

        if (permissionState != PackageManager.PERMISSION_GRANTED) {
            report.append("RESULT: The Sony read permission was not granted.\n");
            showReport(report);
            return;
        }

        ContentResolver resolver = getContentResolver();
        try (Cursor cursor = resolver.query(FIRMWARE_URI, null, null, null, null)) {
            if (cursor == null) {
                report.append("RESULT: NULL_CURSOR\n");
                showReport(report);
                return;
            }

            String[] columns = cursor.getColumnNames();
            report.append("Columns (").append(columns.length).append("):\n");
            for (int i = 0; i < columns.length; i++) {
                report.append("  [").append(i).append("] ").append(columns[i]).append('\n');
            }

            int rowCount = cursor.getCount();
            report.append("\nRows: ").append(rowCount).append('\n');
            if (rowCount == 0) {
                report.append("RESULT: ZERO_FIRMWARE_ROWS\n");
                showReport(report);
                return;
            }

            int row = 0;
            while (cursor.moveToNext() && report.length() < MAX_REPORT_CHARS) {
                report.append("\n--- Row ").append(row++).append(" ---\n");
                for (int i = 0; i < columns.length; i++) {
                    report.append(columns[i]).append('=').append(readValue(cursor, i)).append('\n');
                    if (report.length() >= MAX_REPORT_CHARS) {
                        report.append("\n[REPORT TRUNCATED]\n");
                        break;
                    }
                }
            }
            report.append("\nRESULT: FIRMWARE_ROWS_FOUND\n");
        } catch (SecurityException error) {
            report.append("RESULT: SECURITY_EXCEPTION\n")
                    .append(error.getClass().getName()).append(": ")
                    .append(safeMessage(error)).append('\n');
        } catch (Exception error) {
            report.append("RESULT: QUERY_ERROR\n")
                    .append(error.getClass().getName()).append(": ")
                    .append(safeMessage(error)).append('\n');
        }

        showReport(report);
    }

    private String readValue(Cursor cursor, int column) {
        switch (cursor.getType(column)) {
            case Cursor.FIELD_TYPE_NULL:
                return "<null>";
            case Cursor.FIELD_TYPE_BLOB:
                byte[] blob = cursor.getBlob(column);
                return blob == null ? "<null-blob>" : "<blob:" + blob.length + " bytes>";
            case Cursor.FIELD_TYPE_FLOAT:
                return Double.toString(cursor.getDouble(column));
            case Cursor.FIELD_TYPE_INTEGER:
                return Long.toString(cursor.getLong(column));
            case Cursor.FIELD_TYPE_STRING:
            default:
                String value = cursor.getString(column);
                if (value == null) {
                    return "<null>";
                }
                return redactSensitive(value);
        }
    }

    private String redactSensitive(String value) {
        // Avoid placing a full 15-digit IMEI in a report copied to the Internet.
        return value.replaceAll("(?<![0-9])[0-9]{11}([0-9]{4})(?![0-9])", "***********$1");
    }

    private String safeMessage(Exception error) {
        String message = error.getMessage();
        return message == null ? "<no message>" : redactSensitive(message);
    }

    private void showReport(StringBuilder report) {
        lastReport = report.toString();
        reportView.setText(lastReport);
    }

    private void copyReport() {
        if (lastReport.isEmpty()) {
            Toast.makeText(this, "ماكو تقرير بعد", Toast.LENGTH_SHORT).show();
            return;
        }
        ClipboardManager clipboard =
                (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("Xperia OTA Probe", lastReport));
        Toast.makeText(this, "تم نسخ التقرير", Toast.LENGTH_SHORT).show();
    }
}
