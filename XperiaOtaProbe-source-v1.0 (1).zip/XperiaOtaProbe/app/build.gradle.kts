plugins {
    id("com.android.application")
}

android {
    namespace = "com.mko.xperiaotaprobe"
    compileSdk = 36
    enableKotlin = false

    defaultConfig {
        applicationId = "com.mko.xperiaotaprobe"
        minSdk = 28
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
    }

    buildFeatures {
        buildConfig = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
