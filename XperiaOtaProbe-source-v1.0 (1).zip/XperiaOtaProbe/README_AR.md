# Xperia OTA Probe

أداة تشخيص صغيرة وقراءة فقط لأجهزة Sony Xperia الحديثة.

## ماذا تفعل؟

- تطلب صلاحية Sony العادية `READ_FIRMWARE_UPDATES`.
- تقرأ المسار `content://com.sonyericsson.updatecenter.provider/firmwareUpdate`.
- تعرض أسماء الأعمدة والصفوف التي حفظها Update Center بعد البحث عن تحديث.
- تخفي أي رقم IMEI من 15 رقمًا تلقائيًا قبل نسخ التقرير.

## ماذا لا تفعل؟

- لا تحتوي صلاحية Internet.
- لا تحتوي صلاحية ملفات أو تخزين.
- لا تطلب Root أو Shizuku.
- لا تكتب في قاعدة Update Center ولا تغيّر خصائص النظام.
- لا تفلش أي ملف ولا تفتح Bootloader.

## الاستعمال

1. ثبّت APK وافتحه.
2. اضغط **افتح تحديث النظام**.
3. اضغط **Check for updates** وانتظر ظهور أن الجهاز محدّث.
4. ارجع إلى الأداة واضغط **اقرأ نتيجة Sony**.
5. اضغط **نسخ التقرير** وأرسل النص كاملًا.

إذا ظهر `ZERO_FIRMWARE_ROWS` فهذا يعني أن Update Center لم يخزن أي حزمة Firmware مؤهلة بعد الفحص. إذا ظهر `FIRMWARE_ROWS_FOUND` فالتقرير سيبيّن الحزمة والحالة المخزنة محليًا.

## البناء محليًا

يتطلب Java 17 وGradle 9.4.1 وAndroid SDK 36:

```bash
gradle --no-daemon -p XperiaOtaProbe :app:assembleDebug
```

الناتج:

```text
XperiaOtaProbe/app/build/outputs/apk/debug/app-debug.apk
```
